# pVectors

pVector is a python module designed to help handle vectors, and calculations around them in a simple way. It is written in python and at the moment only supports 2D vectors. This project bases vactors off of the c# implementation of them.
