# pVectors

pVector is a python module designed to help handle vectors, and calculations around them in a simple way. It is written in python and at the moment only supports 2D vectors. This project bases vactors off of the c# implementation of them.

## Dependencies

```text
math
```

The `math` module  is just used for getting some mathmatical constants (pi, e, ...), doing square roots, and sin, and cos.
